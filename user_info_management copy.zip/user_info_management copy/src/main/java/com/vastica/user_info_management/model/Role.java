package com.vastica.user_info_management.model;

import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "role_tbl")
@Data
public class Role {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)

    private int id;
    @Column(name = "role_name")
    private String rolename;
}
